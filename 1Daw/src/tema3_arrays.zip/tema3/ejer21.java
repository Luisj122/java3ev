package tema3;

import java.util.Scanner;

public class ejer21 {

	public static void pintarMatriz(char matriz[][]) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                System.out.print(matriz[i][j]+"  ");
            }
            System.out.println();
        }
    }
	
	public static boolean comprobarGanador(char[][] matriz) {
	
		for(int i=0; i<matriz.length ;i++) {
			for(int j=0 ;j<matriz[i].length ;j++) {
				if(matriz[i][0]=='X') {
					return true;
				}
				
			}
		
		}
		
		return false;
	
	}
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        Scanner sc = new Scanner(System.in);

        char matriz[][]=new char[3][3];
        
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz.length; j++) {
                matriz[i][j]='-';
            }
        }
        
        char jugador1='X';
        char jugador2='O';
        int fila;
        int columna;
        int opcion;
        do {
            System.out.println("Elije posicion");
            System.out.println("1.- Jugador1");
            System.out.println("2.- Jugador2");
            
            opcion=sc.nextInt();
            
            switch (opcion) {
            case 1:
                System.out.println("Elije posicion");
                System.out.println("[0,0], [0,1], [0,2]");
                System.out.println("[1,0], [1,1], [1,2]");
                System.out.println("[2,0], [2,1], [2,2]");
                System.out.println("elije fila");
                fila=sc.nextInt();
                System.out.println("elije columna");
                columna=sc.nextInt();
                if (matriz[fila][columna]==jugador2) {
                    System.out.println("Esta posicion esta ocupada por Jugador 2");
                }else {
                    matriz[fila][columna]=jugador1;
                }
                pintarMatriz(matriz);
                if(comprobarGanador(matriz)) {
                	System.out.println("Gano jugador 1");
                }
                break;
            case 2:
                System.out.println("Elije posicion");
                System.out.println("[0,0], [0,1], [0,2]");
                System.out.println("[1,0], [1,1], [1,2]");
                System.out.println("[2,0], [2,1], [2,2]");
                System.out.println("elije fila");
                fila=sc.nextInt();
                System.out.println("elije columna");
                columna=sc.nextInt();
                if (matriz[fila][columna]==jugador1) {
                    System.out.println("Esta posicion esta ocupada por Jugador 2");
                }else {
                    matriz[fila][columna]=jugador2;
                }
                pintarMatriz(matriz);
                break;
            case 3:
                
                break;

            }
        } while (opcion!=3);
        
        sc.close();
    }

}
