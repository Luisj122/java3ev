/**
 * 
 */
package Tienda;

/**
 * @author alumno
 *
 */
public interface Descontable {

	public double descuento();
}
