package AlquilerPeliculas;

/**
 * 
 * @author usuario
 *Tipo de genero
 */
public enum Genero {
	
	THRILLER, ACCION, AVENTURAS, ROMANTICA, TERROR, INFANTIL, SCIFI, DRAMA, COMEDIA, ORIENTAL
}
