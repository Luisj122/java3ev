package Wordle;

public class testWordle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Wordle w1 = new Wordle();
		System.out.println(w1);
		w1.comprobar("entra");

	}

}
