package ejercicioPoo;

public class testEjer6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ejer6 num = new ejer6();
		num.setNumero(6);
		num.suma(6);
		System.out.println(num);
		num.resta(2);
		System.out.println(num);
	}

}
