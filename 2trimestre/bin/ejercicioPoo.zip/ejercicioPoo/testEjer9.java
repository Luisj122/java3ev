package ejercicioPoo;

public class testEjer9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ejer9 n = new ejer9(1, "abierto");
		ejer9 ns = new ejer9(2, "abierto");
		
		n.resuelve("sldas");
		
		System.out.println(n);
		System.out.println(ns);
		System.out.println(ejer9.getPendientes());

	}

}
