package ejercicioPoo;

public class testTemperatura {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		System.out.println(ejer1.celsiusToFarenheit(25));
		System.out.println(ejer1.farenheitToCelsius(25));
		
		
	}

}
