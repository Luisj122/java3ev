package ejercicioPoo;

public class ejer1 {
	
	//Metodo para cambair de celsius a farenheit
	public static double celsiusToFarenheit(double celsius) {
		
		return (1.8)* celsius + 32;
			
	}
	
	//Metodo para cambiar de farenheit a celsius
	public static double farenheitToCelsius(double farenheit) {
		
		return (farenheit-32)/1.8;
	
				
	}
	
	
	
	
	

}
