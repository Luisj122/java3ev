package ejercicioPoo;

public class testEjer4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		
		System.out.println(ejer4.millasAKilometros(50));
		System.out.println(ejer4.millasAMetros(50));

	}

}
