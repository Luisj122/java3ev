package ejercicioPoo;

public class testCoche {
	public static void main(String[] args) {
		ejer2 coche1 = new ejer2();
		coche1.acelerar(25);
		coche1.frena(15);
		
		System.out.println(coche1);
	}

}
