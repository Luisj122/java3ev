package ejercicioPoo;

public class testEjer11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ejer11 pos = new ejer11(100, 20);
		
		pos.irAbajo();
		System.out.println(pos);
		pos.irAbajo();
		System.out.println(pos);
		pos.irArriba();
		System.out.println(pos);
		pos.irDerecha();
		System.out.println(pos);
		pos.irIzquierda();
		System.out.println(pos);

	}

}
