package ejercicioPoo;

public class ejer3 {
	
		//Compila pero no pinta el color 
	
		public void setedad(int e) { edad=e; }
		public void printedad() { System.out.println(edad); }
		public void setcolor(char c) { color=c; }
		private int edad;
		private char color;
		}

