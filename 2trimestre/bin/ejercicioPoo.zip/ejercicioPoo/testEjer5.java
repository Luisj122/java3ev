package ejercicioPoo;

public class testEjer5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ejer5 d_a = new ejer5();
		
		//Euros a dolares
		
		System.out.println(d_a.dolaresToEuros(25));
		
		//Dolares a euros
	
		System.out.println(d_a.eurosToDorales(25));
		

	}	

}
