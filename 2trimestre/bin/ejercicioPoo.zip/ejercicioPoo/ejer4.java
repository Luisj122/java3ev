package ejercicioPoo;

public class ejer4 {
	
	
	//Conversores
	public static double millasAMetros(double millasM) {
		return (millasM*1600)/1;
	}
	
	public static double millasAKilometros(double millasM) {
		return millasM*1.6;
	}

	
	
}
