package ejercicioPoo;


public class testEjer3 {
	public static void main(String[] args) {
		ejer3 p = new ejer3();
		p.setedad(23);
		p.printedad();
	}

}
