package Scotiky;

public interface Reproducible {
	
	public void reproducir();

}
