package Serie;

public interface Entregable {
	
	public void entregar();
	public void devolver();
	public boolean isPrestado();

}
