package Triangulos;

public interface Comparable {

	public int copareTo(Triangulo t);
}
