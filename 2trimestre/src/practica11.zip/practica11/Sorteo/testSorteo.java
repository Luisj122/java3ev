package Sorteo;

public class testSorteo {

	public static void main(String[] args) {
		
	 Dado d1 = new Dado();
	 
	 System.out.println(d1.lanzar());
	 
	 Moneda m1 = new Moneda();
	 
	 m1.lanzar();
	 
	}

}
