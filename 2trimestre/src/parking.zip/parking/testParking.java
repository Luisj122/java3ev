package parking;

public class testParking  {
	
	public static void main(String[] args) {
		
		
		
	    
	}
}
