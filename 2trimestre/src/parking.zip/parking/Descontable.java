package parking;

public interface Descontable {

	public double descuento();
}
